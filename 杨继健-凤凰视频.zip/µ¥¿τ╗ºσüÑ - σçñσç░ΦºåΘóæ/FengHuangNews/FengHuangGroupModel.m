//
//  FengHuangGroupModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FengHuangGroupModel.h"

@implementation FengHuangGroupModel


+ (NSDictionary *)objectClassInArray{
    return @{@"bodyList" : [FHGroupBodylistModel class], @"header" : [FHGroupHeaderModel class]};
}
@end
@implementation FHGroupBodylistModel

+ (NSDictionary *)objectClassInArray{
    return @{@"videoList" : [FHGroupVideolistModel class]};
}

@end


@implementation FHGroupVideolistModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID": @"id"};
}
@end


@implementation FHGroupMemberitemModel

@end


@implementation FHGroupHeaderModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID": @"id"};
}
@end




