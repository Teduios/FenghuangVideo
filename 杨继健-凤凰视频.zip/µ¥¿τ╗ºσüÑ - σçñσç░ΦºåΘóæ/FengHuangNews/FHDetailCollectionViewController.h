//
//  FHDetailCollectionViewController.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FHDetailViewModel.h"
#import "FHDetailNetManager.h"
@interface FHDetailCollectionViewController : UICollectionViewController
@property (nonatomic)ChanneDetailType infoType;
-(instancetype)initWithInfoType:(ChanneDetailType)type;
@end
