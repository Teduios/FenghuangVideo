//
//  VideoTableViewCell.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoTableViewCell : UITableViewCell
@property (nonatomic, strong) UILabel *titleLB;
@property (nonatomic, strong)  UILabel *playTime;
@property (nonatomic, strong)  UILabel *videoTime;
@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, strong) UIImageView *imageItem1;
@property (nonatomic, strong) UIImageView *imageItem2;

@end
