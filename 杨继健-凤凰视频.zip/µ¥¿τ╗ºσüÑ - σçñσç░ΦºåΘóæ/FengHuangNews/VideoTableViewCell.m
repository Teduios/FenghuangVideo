//
//  VideoTableViewCell.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoTableViewCell.h"

@implementation VideoTableViewCell
-(UILabel *)titleLB
{
    if (!_titleLB) {
        _titleLB = [UILabel new];
        _titleLB.numberOfLines = 0;
        _titleLB.font = [UIFont systemFontOfSize:17];
    }
    return _titleLB;
}
- (UILabel *)playTime {
    if(_playTime == nil) {
        _playTime = [[UILabel alloc] init];
        _playTime.textColor = [UIColor grayColor];
        _playTime.font = [UIFont systemFontOfSize:14];
    }
    return _playTime;
}

- (UILabel *)videoTime {
    if(_videoTime == nil) {
        _videoTime = [[UILabel alloc] init];
        _videoTime.textColor = [UIColor grayColor];
        _videoTime.font = [UIFont systemFontOfSize:14];
    }
    return _videoTime;
}

- (UIImageView *)iconView {
    if(_iconView == nil) {
        _iconView = [[UIImageView alloc] init];
        _iconView.contentMode = 2;
        _iconView.clipsToBounds = YES;
    }
    return _iconView;
}
- (UIImageView *)imageItem1 {
    if(_imageItem1 == nil) {
        _imageItem1 = [[UIImageView alloc] init];
        _imageItem1.image = [UIImage imageNamed:@"playTimeIcon"];
    }
    return _imageItem1;
}

- (UIImageView *)imageItem2 {
    if(_imageItem2 == nil) {
        _imageItem2 = [[UIImageView alloc] init];
        _imageItem2.image = [UIImage imageNamed:@"playNumIcon"];
    }
    return _imageItem2;
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self addSubview:self.titleLB];
        [self addSubview:self.iconView];
        [self addSubview:self.playTime];
        [self addSubview:self.videoTime];
        [self addSubview:self.imageItem1];
        [self addSubview:self.imageItem2];
        [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(8);
            make.width.mas_equalTo(150);
        }];
        [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconView.mas_right).mas_equalTo(8);
            make.right.mas_equalTo(-8);
            make.top.mas_equalTo(3);
            make.height.mas_lessThanOrEqualTo(60);
        }];
        [self.imageItem1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_iconView.mas_right).mas_equalTo(10);
            make.bottom.mas_equalTo(-3);
            make.height.mas_equalTo(_videoTime.mas_height);
        }];
        [self.videoTime mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imageItem1.mas_right).mas_equalTo(0);
            make.bottom.mas_equalTo(-3);
        }];
        [self.imageItem2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_videoTime.mas_right).mas_equalTo(10);
            make.bottom.mas_equalTo(-3);
            make.height.mas_equalTo(_videoTime.mas_height);
        }];
        [self.playTime mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imageItem2.mas_right).mas_equalTo(0);
            make.bottom.mas_equalTo(-3);
        }];
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
