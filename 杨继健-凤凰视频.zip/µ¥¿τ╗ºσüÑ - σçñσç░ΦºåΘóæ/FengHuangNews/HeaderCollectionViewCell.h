//
//  HeaderCollectionViewCell.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"
@interface HeaderCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong)NSMutableArray *headerImages;
@property (nonatomic, strong)NSMutableArray *titles;
@property (nonatomic, assign)NSInteger imagesNumber;
@property (nonatomic, strong)UILabel *lable;
@property (nonatomic, strong)UIPageControl *pageVC;
@property (nonatomic, strong) iCarousel *headerIC;




@end
