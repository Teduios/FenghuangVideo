//
//  FHDetailViewModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ChanneDetailModel.h"
#import "FHDetailNetManager.h"
@interface FHDetailViewModel : BaseViewModel
-(instancetype)initWithInfoType:(ChanneDetailType)type;
@property (nonatomic) ChanneDetailType infoType;
/**
 *  起始页数
 */
@property (nonatomic)NSInteger pageId;
/**
 *  cell个数
 */
@property (nonatomic)NSInteger rowNumber;

-(NSString *)titleInRecomentListFowRow:(NSInteger)row;
-(NSURL *)imageURLInRecomentListFowRow:(NSInteger)row;
-(NSString *)playTimeInRecomentListFowRow:(NSInteger)row;
-(NSString *)durationInRecomentListFowRow:(NSInteger)row;
@end
