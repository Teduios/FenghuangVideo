//
//  LiveCollectionViewCell.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LiveCollectionViewCell.h"
/**
 *  直播首页
 */
@implementation LiveCollectionViewCell
- (UIImageView *)iconVC {
    if(_iconVC == nil) {
        _iconVC = [[UIImageView alloc] init];
        _iconVC.contentMode = 2;
        _iconVC.clipsToBounds = YES;
    }
    return _iconVC;
}

- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] init];
    }
    return _titleLB;
}

- (UILabel *)timeLB {
    if(_timeLB == nil) {
        _timeLB = [[UILabel alloc] init];
        _timeLB.font = [UIFont systemFontOfSize:14];
        _timeLB.textColor = [UIColor grayColor];
    }
    return _timeLB;
}
- (UIButton *)yuyueVC {
    if(_yuyueVC == nil) {
        _yuyueVC = [[UIButton alloc] init];
        _yuyueVC.titleLabel.font = [UIFont systemFontOfSize:12];
        _yuyueVC.userInteractionEnabled = NO;
    }
    return _yuyueVC;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.iconVC];
        [self addSubview:self.titleLB];
        [self addSubview:self.timeLB];
        [self addSubview:self.yuyueVC];
        self.yuye = NO;
        [self.iconVC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            make.height.mas_equalTo(self.mas_height).multipliedBy(0.7);
        }];
       
        [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
           make.left.right.mas_equalTo(0);
            make.top.mas_equalTo(self.iconVC.mas_bottom).mas_equalTo(0);
        }];
        [self.timeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.mas_equalTo(self.titleLB.mas_bottom).mas_equalTo(0);
//            make.right.mas_equalTo(self.yuyueVC.mas_left).mas_equalTo(0);
        }];
        [self.yuyueVC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(50, 25));
            make.right.bottom.mas_equalTo(0);
        }];
        
        
    }
    return self;
}


@end
