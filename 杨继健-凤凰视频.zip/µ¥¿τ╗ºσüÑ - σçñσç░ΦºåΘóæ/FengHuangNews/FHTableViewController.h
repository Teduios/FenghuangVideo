//
//  FHTableViewController.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FHTableViewController : UITableViewController
@property (nonatomic)NSInteger infoType;
@end
