//
//  MyTableViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MyTableViewController.h"
#import "LoginViewController.h"
#import "VideoPlayerViewController.h"
#import "SetTableViewController.h"
@interface MyTableViewController ()<LoginViewControllerDelegate>
@property(nonatomic,strong) NSUserDefaults *userDefault;
@end

@implementation MyTableViewController
-(NSUserDefaults *)userDefault{
    if (!_userDefault) {
        _userDefault=[NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}
-(UIView *)headerView
{
    UIView *hv = [UIView new];
    hv.frame = CGRectMake(0, 0, kWindowW, kWindowH/5);

    UIImageView *bgimg = [[UIImageView alloc]init];
    bgimg.image = [UIImage imageNamed:@"my_background"];
    [hv addSubview:bgimg];
    [bgimg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    UIImageView *headerImg = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"login_account"]];
    [hv addSubview:headerImg];
    [headerImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(hv.mas_centerY);
        make.left.mas_equalTo(20);
    }];
    /**
     登录按钮
     */
    UIButton *login = [[UIButton alloc]init];
    [hv addSubview:login];
    BmobUser *bUser = [BmobUser getCurrentUser];
    if (bUser) {
        [login setTitle:[NSString stringWithFormat:@"欢迎你！%@",[bUser objectForKey:@"username"] ]forState:0];
        [login setUserInteractionEnabled:NO];
    }else{
        [login setTitle:@"点击登录" forState:0];
    }
    [login setTitleColor:[UIColor whiteColor] forState:0];
    [login mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(hv.mas_centerY);
        make.left.mas_equalTo(headerImg.mas_right).mas_equalTo(10);
        
    }];
    [login bk_addEventHandler:^(id sender) {
        LoginViewController *loginvc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"Login"];
        loginvc.delegate = self;
        [self.navigationController pushViewController:loginvc animated:YES];
        
    } forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn1 = [UIButton new];
    [hv addSubview:btn1];
    [btn1 setBackgroundImage:[UIImage imageNamed:@"my_setting"] forState:0];
    [btn1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.bottom.mas_equalTo(0);
    }];
    [btn1 bk_addEventHandler:^(id sender) {
        SetTableViewController *vc = [SetTableViewController new];
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:5];
    
    UIButton *btn2 = [UIButton new];
    [hv addSubview:btn2];
    [btn2 setBackgroundImage:[UIImage imageNamed:@"my_search"] forState:0];
    [btn2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(btn1.mas_left).mas_equalTo(0);
        make.bottom.mas_equalTo(0);
    }];
    [btn2 bk_addEventHandler:^(id sender) {
        UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"Search"];
        [self presentViewController:vc animated:YES completion:nil];
        
    } forControlEvents:5];
    
    return hv;
}
-(void)userLogin
{
    
}
-(void)getUserInfoWithDic:(NSString *)name
{
    self.name = name;
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.tableHeaderView = [self headerView];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
}
-(void)viewWillAppear:(BOOL)animated
{
    self.tableView.tableHeaderView = [self headerView];
    [self.tableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
//-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//    return 120;
//}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.userDefault arrayForKey:@"info"].count+1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    if (indexPath.row == 0) {
        UIImageView *img = [UIImageView new];
        [img setImage:[UIImage imageNamed:@"my_watch_Record"]];
        img.contentMode =1;
        [cell.contentView addSubview:img];
        [img mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.centerY.mas_equalTo(cell.mas_centerY);
            make.size.mas_equalTo(CGSizeMake(100, 30));
        }];
    }else{
        cell.textLabel.text = [self.userDefault arrayForKey:@"info"][indexPath.row-1];
    }
    
    return cell;
}

kRemoveCellSeparator
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    VideoPlayerViewController *vc = [[VideoPlayerViewController alloc]init];
    vc.guid = [self.userDefault arrayForKey:@"Guid"][indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
