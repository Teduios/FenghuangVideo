//
//  ZhuanTiModel.m
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/25.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZhuanTiModel.h"

@implementation ZhuanTiModel


+ (NSDictionary *)objectClassInArray{
    return @{@"extendData" : [ExtenddataModel class], @"subTopicList" : [SubtopiclistModel class]};
}
@end
@implementation ExtenddataModel

@end


@implementation SubtopiclistModel

+ (NSDictionary *)objectClassInArray{
    return @{@"detailList" : [DetaillistModel class]};
}

@end


@implementation DetaillistModel

@end


@implementation MemberitemModel

+ (NSDictionary *)objectClassInArray{
    return @{@"files" : [FilesModel class]};
}

@end


@implementation FilesModel

@end


