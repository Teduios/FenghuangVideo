//
//  FHDetailNetManager.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHDetailNetManager.h"
#import "ChanneDetailModel.h"
#define kDetailPath @"http://vcsp.ifeng.com/vcsp/appData/getChannelDetail.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&statisticChannelId=%@&positionNo=%ld"
@implementation FHDetailNetManager
+(id)getChanneDetailWithType:(ChanneDetailType)type pageID:(NSInteger)pageId completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = nil;
    switch (type) {
        case ChanneDetailTypeJunShi: {
            path = [NSString stringWithFormat:kDetailPath,@"100464-100465",pageId];
            break;
        }
        case ChanneDetailTypeLiShi: {
             path = [NSString stringWithFormat:kDetailPath,@"100464-100466",pageId];
            break;
        }
        case ChanneDetailTypeSheHui: {
             path = [NSString stringWithFormat:kDetailPath,@"100464-100467",pageId];
            break;
        }
        case ChanneDetailTypeRenWu: {
             path = [NSString stringWithFormat:kDetailPath,@"100464-100468",pageId];
            break;
        }
        case ChanneDetailTypeTanSuo: {
             path = [NSString stringWithFormat:kDetailPath,@"100464-100469",pageId];
            break;
        }
        case ChanneDetailTypeWenHua: {
             path = [NSString stringWithFormat:kDetailPath,@"100464-100470",pageId];
            break;
        }
        default: {
            
            break;
        }
    }
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ChanneDetailModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
