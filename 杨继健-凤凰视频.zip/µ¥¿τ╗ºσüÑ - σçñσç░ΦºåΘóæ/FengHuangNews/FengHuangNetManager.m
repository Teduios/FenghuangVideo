//
//  FengHuangNetManager.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FengHuangNetManager.h"
#import "FengHuangModel.h"
#import "FengHuangGroupModel.h"
#define kGroupPath @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.2&isNotModified=0&useType=androidPhone&channelId=%@&positionId=%ld"
@implementation FengHuangNetManager
/**
 * useType=androidPhone&channelId=100409-0&isNotModified=0&adapterNo=6.9.2&callBy=new
 */
+(id)getJingXuanWithID:(NSString *)ID completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = @"http://vcsp.ifeng.com/vcsp/appData/homePageList.do";
    NSDictionary *parms = @{@"useType":@"androidPhone",@"channelId":ID,@"isNotModified":@"0",@"adapterNo":@"6.9.2",@"callBy":@"new"};
    return [self GET:path parameters:parms completionHandler:^(id responseObj, NSError *error) {
        completionHandle([FengHuangModel mj_objectWithKeyValues:responseObj],error);
    }];
}
/**
 *  娱乐
 http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.2&isNotModified=0&useType=androidPhone&channelId=100391-0&positionId=0
 
 军事
 http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20& adapterNo=6.9.2&isNotModified=0&useType=androidPhone&channelId=100377-0&positionId=0
 
 社会
 http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20& adapterNo=6.9.2&isNotModified=0&useType=androidPhone&channelId=100413-0&positionId=0
 
 搞笑
 http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20& adapterNo=6.9.2&isNotModified=0&useType=androidPhone&channelId=100473-0&positionId=0
 
 原创
 http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20& adapterNo=6.9.2&isNotModified=0&useType=androidPhone&channelId=127952-0&positionId=0
 
 历史
 http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20& adapterNo=6.9.2&isNotModified=0&useType=androidPhone&channelId=100384-0&positionId=0

 */
+(id)getFengHuangWithType:(FengHuangType)type positionId:(NSInteger)pageId completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path =nil;
    switch (type) {
        case FengHuangTypeYuLe: {
            path = [NSString stringWithFormat:kGroupPath,@"100391-0",pageId];
            break;
        }
        case FengHuangTypeJunShi: {
            path = [NSString stringWithFormat:kGroupPath,@"100377-0",pageId];
            break;
        }
        case FengHuangTypeSeHui: {
            path = [NSString stringWithFormat:kGroupPath,@"100413-0",pageId];
            break;
        }
        case FengHuangTypeGaoXiao: {
            path = [NSString stringWithFormat:kGroupPath,@"100473-0",pageId];
            break;
        }
        case FengHuangTypeYuanChuang: {
            path = [NSString stringWithFormat:kGroupPath,@"127952-0",pageId];
            break;
        }
        case FengHuangTypeLiShi: {
            path = [NSString stringWithFormat:kGroupPath,@"100384-0",pageId];
            break;
        }
        case FengHuangTypeMeiNv:
            path = [NSString stringWithFormat:kGroupPath,@"100477-0",pageId];
            break;
        case FengHuangTypeTuiJian:
            path = [NSString stringWithFormat:kGroupPath,@"100464-0",pageId];
            break;
        default: {
            DDLogVerbose(@"类型不对");
            break;
        }
    }
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([FengHuangGroupModel mj_objectWithKeyValues:responseObj],error);
    }];
    
}
@end
