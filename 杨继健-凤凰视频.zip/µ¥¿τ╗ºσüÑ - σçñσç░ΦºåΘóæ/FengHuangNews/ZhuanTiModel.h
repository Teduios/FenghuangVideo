//
//  ZhuanTiModel.h
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/25.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseModel.h"

@class ExtenddataModel,SubtopiclistModel,DetaillistModel,MemberitemModel,FilesModel;
@interface ZhuanTiModel : BaseModel

@property (nonatomic, strong) NSArray<ExtenddataModel *> *extendData;

@property (nonatomic, strong) NSArray<SubtopiclistModel *> *subTopicList;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *largePoster;

@property (nonatomic, copy) NSString *topicShareURL;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *smallPoster;

@end
@interface ExtenddataModel : NSObject

@property (nonatomic, copy) NSString *linkType;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *sys_publisher;

@property (nonatomic, copy) NSString *extTitle;

@property (nonatomic, copy) NSString *sys_publishDateTime;

@property (nonatomic, copy) NSString *image;

@end

@interface SubtopiclistModel : NSObject

@property (nonatomic, copy) NSString *subId;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *subStyle;

@property (nonatomic, assign) NSInteger orderCount;

@property (nonatomic, strong) NSArray<DetaillistModel *> *detailList;

@end

@interface DetaillistModel : NSObject

@property (nonatomic, copy) NSString *statisticID;

@property (nonatomic, copy) NSString *thumbImageUrl;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) MemberitemModel *memberItem;

@property (nonatomic, copy) NSString *memberType;

@property (nonatomic, copy) NSString *memberId;

@property (nonatomic, copy) NSString *createTime;

@end

@interface MemberitemModel : NSObject

@property (nonatomic, copy) NSString *cpName;

@property (nonatomic, strong) NSArray<FilesModel *> *files;

@property (nonatomic, copy) NSString *itemId;

@property (nonatomic, copy) NSString *searchPath;

@property (nonatomic, copy) NSString *createTime;

@property (nonatomic, assign) NSInteger duration;

@property (nonatomic, copy) NSString *createDate;

@property (nonatomic, copy) NSString *guid;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *playTime;

@end

@interface FilesModel : NSObject

@property (nonatomic, assign) NSInteger filesize;

@property (nonatomic, copy) NSString *spliteTime;

@property (nonatomic, assign) NSInteger useType;

@property (nonatomic, copy) NSString *mediaUrl;

@property (nonatomic, copy) NSString *createTime;

@end

