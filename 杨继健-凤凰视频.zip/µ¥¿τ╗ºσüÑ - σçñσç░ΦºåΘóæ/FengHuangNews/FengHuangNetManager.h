//
//  FengHuangNetManager.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
typedef NS_ENUM(NSUInteger, FengHuangType) {
    FengHuangTypeYuLe,
    FengHuangTypeJunShi,
    FengHuangTypeSeHui,
    FengHuangTypeGaoXiao,
    FengHuangTypeYuanChuang,
    FengHuangTypeLiShi,
    FengHuangTypeMeiNv,
    FengHuangTypeTuiJian,
};
@interface FengHuangNetManager : BaseNetManager
+(id)getJingXuanWithID:(NSString *)ID kCompletionHandle;

+(id)getFengHuangWithType:(FengHuangType)type positionId:(NSInteger )pageId kCompletionHandle;
@end
