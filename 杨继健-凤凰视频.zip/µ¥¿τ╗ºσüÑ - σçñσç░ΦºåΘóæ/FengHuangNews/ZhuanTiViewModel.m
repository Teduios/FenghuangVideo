//
//  ZhuanTiViewModel.m
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/25.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZhuanTiViewModel.h"
#import "ZhuanTiNetManger.h"
#import "ZhuanTiModel.h"
@implementation ZhuanTiViewModel
-(instancetype)initWithMemberId:(NSString *)memberId
{
    if (self = [super init]) {
        self.memberId = memberId;
    }
    return self;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [ZhuanTiNetManger getVideoDataWithMemberID:self.memberId completionHandle:^(ZhuanTiModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.subTopicList];
        SubtopiclistModel *model1 = self.dataArr.firstObject;
        self.guid = model1.detailList.firstObject.memberItem.guid;
        completionHandle(error);
    } ];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(NSString *)getGuidForZhuanTi
{
    SubtopiclistModel *model = self.dataArr.firstObject;
    return  model.detailList.firstObject.memberItem.guid;
}
@end
