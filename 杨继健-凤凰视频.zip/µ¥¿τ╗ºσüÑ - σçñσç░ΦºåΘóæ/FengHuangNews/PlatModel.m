//
//  PlatModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PlatModel.h"

@implementation PlatModel


+ (NSDictionary *)objectClassInArray{
    return @{@"liveInfo" : [PlatLiveinfoModel class]};
}
@end
@implementation PlatLiveinfoModel
+(NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"desc":@"description"};
}
@end


