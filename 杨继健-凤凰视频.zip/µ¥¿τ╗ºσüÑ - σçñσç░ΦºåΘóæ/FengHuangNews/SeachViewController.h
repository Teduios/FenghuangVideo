//
//  SeachViewController.h
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/23.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeachViewController : UIViewController

@end
