//
//  LiveViewController.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LiveInfoViewModel.h"
@interface LiveViewController : UIViewController
@property (nonatomic)PlatType infoType;
@end
