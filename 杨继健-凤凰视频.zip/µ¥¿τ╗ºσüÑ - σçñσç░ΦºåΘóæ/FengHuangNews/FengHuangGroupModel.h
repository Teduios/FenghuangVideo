//
//  FengHuangGroupModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class FHGroupBodylistModel,FHGroupVideolistModel,FHGroupMemberitemModel,FHGroupHeaderModel,FHGroupMemberitemModel;
@interface FengHuangGroupModel : BaseModel

@property (nonatomic, copy) NSString *relateDes;

@property (nonatomic, strong) NSArray<FHGroupBodylistModel *> *bodyList;

@property (nonatomic, copy) NSString *relate;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray<FHGroupHeaderModel *> *header;

@end
@interface FHGroupBodylistModel : NSObject

@property (nonatomic, strong) NSArray<FHGroupVideolistModel *> *videoList;

@property (nonatomic, copy) NSString *memberIds;

@property (nonatomic, strong) NSArray<NSString *> *itemIdList;

@property (nonatomic, copy) NSString *showType;

@end

@interface FHGroupVideolistModel : NSObject

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *geography;

@property (nonatomic, copy) NSString *memberType;

@property (nonatomic, copy) NSString *ratio;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *abstractDesc;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *memberId;

@property (nonatomic, copy) NSString *tag;

@property (nonatomic, copy) NSString *coordinate;

@property (nonatomic, strong) FHGroupMemberitemModel *memberItem;

@property (nonatomic, copy) NSString *playTime;

@property (nonatomic, copy) NSString *itemId;

@end

@interface FHGroupMemberitemModel : NSObject

@property (nonatomic, assign) NSInteger duration;

@property (nonatomic, copy) NSString *itemId;

@property (nonatomic, copy) NSString *createDate;

@property (nonatomic, copy) NSString *guid;

@end

@interface FHGroupHeaderModel : NSObject

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, strong) FHGroupMemberitemModel *memberItem;

@property (nonatomic, copy) NSString *memberType;

@property (nonatomic, copy) NSString *memberId;

@property (nonatomic, copy) NSString *tag;

@property (nonatomic, copy) NSString *abstractDesc;

@property (nonatomic, copy) NSString *playTime;

@end



