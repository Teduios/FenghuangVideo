//
//  LiveInfoViewModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "PlatNetManger.h"
@interface LiveInfoViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;
@property (nonatomic)PlatType infoType;
-(instancetype)initWithType:(PlatType)type ;
-(NSURL *)bkgIconURLForLiveInfo:(NSInteger)row;
-(NSString *)titlwForLiveInfo:(NSInteger)row;
-(NSURL *)playerURLForLiveInfo:(NSInteger)row;
@end
