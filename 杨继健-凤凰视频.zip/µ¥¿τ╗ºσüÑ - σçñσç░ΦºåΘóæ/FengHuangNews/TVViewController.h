//
//  TVViewController.h
//  FengHuangNews
//
//  Created by apple-jd05 on 15/12/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVViewController : UIViewController
@property (nonatomic, strong)NSURL *webURL;
@end
