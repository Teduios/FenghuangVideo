//
//  LoginViewController.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol LoginViewControllerDelegate
-(void)getUserInfoWithDic:(NSString *)name;
@end
@interface LoginViewController : UIViewController
@property (nonatomic, strong)id<LoginViewControllerDelegate> delegate;
@end
