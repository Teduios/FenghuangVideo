//
//  LiveCollectionViewCell.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LiveCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong)UIImageView *iconVC;
@property (nonatomic, strong)UILabel *titleLB;
@property (nonatomic, strong)UILabel *timeLB;
@property (nonatomic, strong)UIButton *yuyueVC;
@property (nonatomic, getter=isYuye) BOOL yuye;

@end
