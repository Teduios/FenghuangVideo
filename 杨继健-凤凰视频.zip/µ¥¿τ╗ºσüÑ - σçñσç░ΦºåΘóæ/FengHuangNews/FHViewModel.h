//
//  FHViewModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "FengHuangNetManager.h"
@interface FHViewModel : BaseViewModel

/**
 隐藏专题图标
 */
-(BOOL)isHiddenWithRow:(NSIndexPath *)indexPath;
-(BOOL)isVideoWithRow:(NSIndexPath *)indexPath;
-(BOOL)isCmpptopicWithRow:(NSIndexPath *)indexPath;
/**
 标题
 */
-(NSString *)titleForIndexInRecommendList:(NSIndexPath *)index;
/**
 图片URL
 */
-(NSURL *)iconURLForIndexInRecommendList:(NSIndexPath *)index;
/**
 播放次数
 */
-(NSString *)playTimeForIndexInRecommendList:(NSIndexPath *)index;
/**
 视频时长
 */
-(NSString *)durationForIndexInRecommendList:(NSIndexPath *)index;
/**
 *  获得分区行数
 */
-(NSInteger)rowNumberWithSection:(NSInteger)section;
/**
 *  分区标题
 */
-(NSString *)groupTitleForSection:(NSInteger)section;

/**
 *详细信息
 */
-(NSString *)descInRecommendForIndexPath:(NSIndexPath *)index;
/**
 点击后获得链接
 */
-(NSString *)guidInRecommendForIndexPath:(NSIndexPath *)index;

-(NSString *)memberidInRecommendForIndexPath:(NSIndexPath *)index;
/**
 *  头部数组
 */
@property (nonatomic, strong) NSArray *headerArr;
@property (nonatomic) NSInteger headRowNumber;

-(NSString *)titleInHeaderForRow:(NSInteger )row;
-(NSURL *)imageURLInHeaderForRow:(NSInteger )row;
-(NSString *)guidInHeaderForRow:(NSInteger )row;

@end
