//
//  FHGroupCollectionViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHGroupCollectionViewController.h"
#import "FHCollectionViewCell.h"
#import "HeaderCollectionViewCell.h"
#import "VideoPlayerViewController.h"
@interface FHGroupCollectionViewController ()<UICollectionViewDelegateFlowLayout>
@property (nonatomic, strong) FHGroupViewModel *groupVM;

@end

@implementation FHGroupCollectionViewController
-(instancetype)init
{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    self = [self initWithCollectionViewLayout:layout];
    if (self) {
    }
    return self;
    
}

- (FHGroupViewModel *)groupVM {
    if(_groupVM == nil) {
        _groupVM = [[FHGroupViewModel alloc] initWithInfoType:_infoType];
    }
    return _groupVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.backgroundColor = [UIColor whiteColor];
    
    
    [self.collectionView registerClass:[HeaderCollectionViewCell class] forCellWithReuseIdentifier:@"HeaderCell"];
    [self.collectionView registerClass:[FHCollectionViewCell class] forCellWithReuseIdentifier:@"Cell"];
    
    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.groupVM refreshDataCompletionHandle:^(NSError *error) {
            [self.collectionView.mj_header endRefreshing];
            [self.collectionView reloadData];
        }];
    }];
    [self.collectionView.mj_header beginRefreshing];
    self.collectionView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.groupVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.collectionView.mj_footer endRefreshing];
            [self.collectionView reloadData];
        }];
        
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }
    return self.groupVM.rowNumber;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        HeaderCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HeaderCell"forIndexPath:indexPath];
        cell.lable.text = [self.groupVM titleInHeaderForRow:0];
        cell.pageVC.numberOfPages = self.groupVM.headRowNumber;
        for (int i = 0; i<self.groupVM.headRowNumber; i++) {
            [cell.titles addObject:[self.groupVM titleInHeaderForRow:i]];
            [cell.headerImages addObject:[self.groupVM imageURLInHeaderForRow:i]];
        }
        [cell.headerIC reloadData];
        return cell;
    }
    FHCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    cell.iconTV.image = nil;
    [cell.iconTV setImageWithURL:[self.groupVM imageURLInRecomentListFowRow:indexPath.row]placeholderImage:[UIImage imageNamed:@"Default_Logo"]];
    
    cell.titleLB.text = [self.groupVM titleInRecomentListFowRow:indexPath.row];
    cell.playTIme.text = [self.groupVM playTimeInRecomentListFowRow:indexPath.row];
    cell.videoTime.text = [self.groupVM durationInRecomentListFowRow:indexPath.row];
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%ld",indexPath.row);
    VideoPlayerViewController *vc = [VideoPlayerViewController new];
    vc.guid = [self.groupVM guiIdListInRecomentListFowRow:indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma mark <UICollectionViewDelegate>
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 10;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
  
    return 10;
}
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
   
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return CGSizeMake(kWindowW, kWindowW/750 * 500);
    }
    CGFloat width = (kWindowW-30)/2.0;
    CGFloat height = kWindowH/5.0;
    return CGSizeMake(width, height);
}



@end
