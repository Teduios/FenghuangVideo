//
//  LiveViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LiveViewController.h"
#import "TVCollectionViewCell.h"
#import "TVViewController.h"
@interface LiveViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UIWebViewDelegate>
@property (nonatomic, strong) LiveInfoViewModel *liveVM;
@end

@implementation LiveViewController
- (LiveInfoViewModel *)liveVM {
    if(_liveVM == nil) {
        _liveVM = [[LiveInfoViewModel alloc] initWithType:self.infoType];
    }
    return _liveVM;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake((kWindowW-30)/2, 120);
    layout.minimumInteritemSpacing = 5;
    layout.minimumLineSpacing = 5; //上下的间距 可以设置0看下效果
    layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    
    UICollectionView *infoCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH) collectionViewLayout:layout];
    infoCollectionView.delegate =self;
    infoCollectionView.dataSource = self;
    infoCollectionView.backgroundColor = [UIColor whiteColor];
    
    [infoCollectionView registerClass:[TVCollectionViewCell class] forCellWithReuseIdentifier:@"Cell"];
    
    [self.view addSubview:infoCollectionView];
    [infoCollectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    infoCollectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.liveVM refreshDataCompletionHandle:^(NSError *error) {
                [infoCollectionView reloadData];
                [infoCollectionView.mj_header endRefreshing];
        
        }];
    }];
    dispatch_async(dispatch_get_main_queue(), ^{
        [infoCollectionView.mj_header beginRefreshing];
    });
    

}
#pragma  mark - UICollectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.liveVM.rowNumber;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    TVCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    
    [cell.iconTV setImageWithURL:[self.liveVM bkgIconURLForLiveInfo:indexPath.row]];
    cell.layer.borderWidth = 2;
    cell.lable.text = [self.liveVM titlwForLiveInfo:indexPath.row];
    
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    TVViewController *vc = [TVViewController new];
    vc.webURL = [self.liveVM playerURLForLiveInfo:indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
