//
//  PlatModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class PlatLiveinfoModel;
@interface PlatModel : BaseModel

@property (nonatomic, strong) NSArray<PlatLiveinfoModel *> *liveInfo;

@end
@interface PlatLiveinfoModel : NSObject

@property (nonatomic, assign) NSInteger online;

@property (nonatomic, copy) NSString *videoInReview;

@property (nonatomic, copy) NSString *videoL;

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *spVideo;

@property (nonatomic, copy) NSString *bkgURL;

@property (nonatomic, copy) NSString *bigIconURL;

@property (nonatomic, copy) NSString *video;

@property (nonatomic, copy) NSString *shareUrl;

@property (nonatomic, copy) NSString *useType;

@property (nonatomic, copy) NSString *spAudio;

@property (nonatomic, copy) NSString *videoM;

@property (nonatomic, copy) NSString *liveCategory;

@property (nonatomic, copy) NSString *audio;

@property (nonatomic, copy) NSString *videoH;

@property (nonatomic, copy) NSString *deType;

@property (nonatomic, copy) NSString *cName;

@property (nonatomic, copy) NSString *channelId;

@property (nonatomic, copy) NSString *desc;

@end

