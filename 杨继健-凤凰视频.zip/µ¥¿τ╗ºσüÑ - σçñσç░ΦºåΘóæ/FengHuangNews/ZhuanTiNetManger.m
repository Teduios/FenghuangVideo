//
//  ZhuanTiNetManger.m
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/25.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZhuanTiNetManger.h"
#import "ZhuanTiModel.h"
#define kZhuanTiPath @"http://vcsp.ifeng.com/vcsp/appData/getDetailTopic.do?useType=iPhone&itemType=cmppTopic&itemId=%@"
@implementation ZhuanTiNetManger
+(id)getVideoDataWithMemberID:(NSString *)menberId completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = [NSString stringWithFormat:kZhuanTiPath,menberId];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ZhuanTiModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
