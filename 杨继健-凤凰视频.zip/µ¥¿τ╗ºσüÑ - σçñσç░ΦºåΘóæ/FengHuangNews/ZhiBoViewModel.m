//
//  ZhiBoViewModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZhiBoViewModel.h"

@implementation ZhiBoViewModel
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [DirectNetManager getDirectDataCompletionHandle:^(FHDirectModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.bodyList];
        
        self.headerURL = [NSURL URLWithString:model.header.firstObject.video];
        completionHandle(error);
    }];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(NSInteger)rowNumber
{
    return self.dataArr.count;
}
-(DirectBodylist *)directBodylistForRow:(NSInteger)row
{
    if (self.dataArr == nil|| self.dataArr.count == 0) {
        return nil;
    }
    return self.dataArr[row];
}
-(NSURL *)iconURLForliveRecommend:(NSInteger)row
{
    return [NSURL URLWithString:[self directBodylistForRow:row].image];
}
-(NSString *)titleForliveRecommend:(NSInteger)row
{
    return [self directBodylistForRow:row].programTitle;
}
-(NSString *)startTimeForliveRecommend:(NSInteger)row
{
    return [self directBodylistForRow:row].startTime;
}
-(NSURL *)videoForliveRecommend:(NSInteger)row
{
    return [NSURL URLWithString:[self directBodylistForRow:row].video];
}


@end
