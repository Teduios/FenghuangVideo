//
//  VideoPlayerViewController.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "videoViewModel.h"
@interface VideoPlayerViewController : UIViewController
@property (nonatomic, strong) NSString *guid;
@property (nonatomic, strong) NSString *memberid;
@end
