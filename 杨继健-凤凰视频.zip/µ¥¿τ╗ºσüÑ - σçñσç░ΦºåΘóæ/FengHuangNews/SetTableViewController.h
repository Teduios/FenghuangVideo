//
//  SetTableViewController.h
//  FengHuangNews
//
//  Created by apple-jd05 on 15/12/2.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetTableViewController : UITableViewController

@end
