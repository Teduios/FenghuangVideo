//
//  GuidRelativeModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class FHGuidrelativevideoinfoModel,FHFilesModel;
@interface GuidRelativeModel : BaseModel

@property (nonatomic, strong) NSArray<FHGuidrelativevideoinfoModel *> *guidRelativeVideoInfo;

@end
@interface FHGuidrelativevideoinfoModel : NSObject

@property (nonatomic, copy) NSString *cpName;

@property (nonatomic, copy) NSString *playTime;

@property (nonatomic, strong) NSArray<FHFilesModel *> *files;

@property (nonatomic, copy) NSString *searchPath;

@property (nonatomic, copy) NSString *itemId;

@property (nonatomic, copy) NSString *seTitle;

@property (nonatomic, assign) NSInteger duration;

@property (nonatomic, copy) NSString *createDate;

@property (nonatomic, copy) NSString *guid;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *columnName;

@end

@interface FHFilesModel : NSObject

@property (nonatomic, assign) NSInteger filesize;

@property (nonatomic, copy) NSString *spliteTime;

@property (nonatomic, assign) NSInteger useType;

@property (nonatomic, copy) NSString *mediaUrl;

@end

