//
//  VideoNetManager.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "GuidRelativeModel.h"
@interface VideoNetManager : BaseNetManager
+(id)getVideoDataWithGuId:(NSString *)guid kCompletionHandle;
@end
