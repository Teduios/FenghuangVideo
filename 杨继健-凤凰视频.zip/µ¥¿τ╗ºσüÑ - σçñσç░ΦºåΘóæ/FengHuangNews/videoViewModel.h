//
//  videoViewModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideoNetManager.h"
@interface videoViewModel : BaseViewModel
@property (nonatomic, strong)NSString *guid;
-(instancetype)initWithGuid:(NSString *)guid;
@property (nonatomic) NSInteger rowNumber;
-(NSURL *)mediaURLForRow:(NSInteger)row;
-(NSURL *)iconUrlForRow:(NSInteger)row;
-(NSString *)nameForRow:(NSInteger)row;
-(NSString *)playTimeFowRow:(NSInteger)row;
-(NSString *)durationFowRow:(NSInteger)row;
-(NSString *)guidFowRow:(NSInteger)row;
@end
