//
//  RegistViewController.h
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/24.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistViewController : UIViewController

@end
