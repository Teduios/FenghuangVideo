//
//  VideoNetManager.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoNetManager.h"
#define kGuidPath  @"http://vcsp.ifeng.com/vcsp/appData/getGuidRelativeVideoList.do?pageSize=20&guid=%@"
@implementation VideoNetManager
+(id)getVideoDataWithGuId:(NSString *)guid completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = [NSString stringWithFormat:kGuidPath,guid];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([GuidRelativeModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
