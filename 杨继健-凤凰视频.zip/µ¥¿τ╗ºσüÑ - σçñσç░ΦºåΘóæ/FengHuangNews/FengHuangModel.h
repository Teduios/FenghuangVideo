//
//  FengHuangModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class FHBodyrecommendModel,FHRecommendlistModel,FHGrouplistModel,FHRecommendModel,FHHeaderModel,FHMemberitemModel;
@interface FengHuangModel : BaseModel

@property (nonatomic, strong) FHBodyrecommendModel *bodyRecommend;

@property (nonatomic, copy) NSString *relate;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray<FHHeaderModel *> *header;

@end
@interface FHBodyrecommendModel : BaseModel

@property (nonatomic, strong) NSArray<FHRecommendlistModel *> *recommendList;

@end

@interface FHRecommendlistModel : BaseModel

@property (nonatomic, copy) NSString *showType;

@property (nonatomic, copy) NSString *groupTitle;

@property (nonatomic, strong) NSArray<FHRecommendModel *> *recommend;

@property (nonatomic, strong) NSArray<FHGrouplistModel *> *groupList;

@end

@interface FHGrouplistModel : BaseModel

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *updateTime;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *memberType;

@property (nonatomic, copy) NSString *tag;

@property (nonatomic, copy) NSString *memberId;

@property (nonatomic, copy) NSString *abstractDesc;

@property (nonatomic, copy) NSString *playTime;

@property (nonatomic, strong) FHMemberitemModel *memberItem;
@end

@interface FHRecommendModel : BaseModel

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *name;

@end

@interface FHHeaderModel : BaseModel

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *updateTime;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, strong) FHMemberitemModel *memberItem;

@property (nonatomic, copy) NSString *mediaUrl;

@property (nonatomic, copy) NSString *memberType;

@property (nonatomic, copy) NSString *memberId;

@property (nonatomic, copy) NSString *abstractDesc;

@property (nonatomic, copy) NSString *tag;

@end

@interface FHMemberitemModel : BaseModel

@property (nonatomic, copy) NSString *searchPath;

@property (nonatomic, copy) NSString *updateTime;

@property (nonatomic, assign) NSInteger duration;

@property (nonatomic, copy) NSString *createDate;

@property (nonatomic, copy) NSString *guid;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *columnName;

@end

