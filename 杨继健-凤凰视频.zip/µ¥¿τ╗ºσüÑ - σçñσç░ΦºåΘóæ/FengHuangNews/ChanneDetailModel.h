//
//  ChanneDetailModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class DetailBodylistModel,DetailFilesModel;
@interface ChanneDetailModel : BaseModel

@property (nonatomic, copy) NSString *channelPicPressUrl;

@property (nonatomic, copy) NSString *statisticChannelId;

@property (nonatomic, copy) NSString *channelId;

@property (nonatomic, strong) NSArray<DetailBodylistModel *> *bodyList;

@property (nonatomic, copy) NSString *channelName;

@property (nonatomic, copy) NSString *channelPicSelectUrl;

@property (nonatomic, copy) NSString *zhHantName;

@property (nonatomic, assign) NSInteger useType;

@property (nonatomic, copy) NSString *channelPicUrl;

@end
@interface DetailBodylistModel : BaseModel

@property (nonatomic, copy) NSString *columnName;

@property (nonatomic, copy) NSString *guid;

@property (nonatomic, copy) NSString *summary;

@property (nonatomic, copy) NSString *keyWord;

@property (nonatomic, copy) NSString *categoryName;

@property (nonatomic, assign) NSInteger duration;

@property (nonatomic, assign) NSInteger publishYear;

@property (nonatomic, copy) NSString *seTitle;

@property (nonatomic, assign) NSInteger recommLevel;

@property (nonatomic, strong) NSArray<DetailFilesModel *> *files;

@property (nonatomic, assign) NSInteger episodeNum;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger teleplayIndex;

@property (nonatomic, copy) NSString *telDescripton;

@property (nonatomic, assign) NSInteger isSplit;

@property (nonatomic, copy) NSString *seVersion;

@property (nonatomic, copy) NSString *cpId;

@property (nonatomic, copy) NSString *spId;

@property (nonatomic, assign) NSInteger splitNum;

@property (nonatomic, copy) NSString *cpName;

@property (nonatomic, copy) NSString *createDate;

@property (nonatomic, copy) NSString *searchPath;

@property (nonatomic, copy) NSString *playTime;

@property (nonatomic, copy) NSString *categoryId;

@property (nonatomic, copy) NSString *author;

@end

@interface DetailFilesModel : BaseModel

@property (nonatomic, assign) NSInteger isSplite;

@property (nonatomic, copy) NSString *spliteTime;

@property (nonatomic, assign) NSInteger filesize;

@property (nonatomic, copy) NSString *mediaUrl;

@property (nonatomic, assign) NSInteger spliteNo;

@property (nonatomic, copy) NSString *useTypeName;

@property (nonatomic, copy) NSString *programId;

@property (nonatomic, assign) NSInteger useType;

@end

