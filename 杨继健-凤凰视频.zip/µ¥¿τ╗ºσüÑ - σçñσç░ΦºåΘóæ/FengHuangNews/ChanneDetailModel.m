//
//  ChanneDetailModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ChanneDetailModel.h"

@implementation ChanneDetailModel


+ (NSDictionary *)objectClassInArray{
    return @{@"bodyList" : [DetailBodylistModel class]};
}
@end
@implementation DetailBodylistModel

+ (NSDictionary *)objectClassInArray{
    return @{@"files" : [DetailFilesModel class]};
}

@end


@implementation DetailFilesModel

@end


