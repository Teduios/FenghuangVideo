//
//  FHDetailViewModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHDetailViewModel.h"

@implementation FHDetailViewModel
-(instancetype)initWithInfoType:(ChanneDetailType)type
{
    if (self = [super init]) {
        self.infoType = type;
    }
    return self;
}

-(NSInteger)rowNumber
{
    return self.dataArr.count;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [FHDetailNetManager getChanneDetailWithType:self.infoType pageID:_pageId completionHandle:^(ChanneDetailModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.bodyList];
        completionHandle(error);
    }];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.pageId = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.pageId = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(DetailBodylistModel *)bodyListModelForRow:(NSInteger)row
{
    return self.dataArr[row];
}
-(NSString *)titleInRecomentListFowRow:(NSInteger)row
{
    return [self bodyListModelForRow:row].name;
}
-(NSURL *)imageURLInRecomentListFowRow:(NSInteger)row
{
    return [NSURL URLWithString:[self bodyListModelForRow:row].files[1].mediaUrl];
}
-(NSString *)playTimeInRecomentListFowRow:(NSInteger)row
{
    return [self bodyListModelForRow:row].playTime;
}
-(NSString *)durationInRecomentListFowRow:(NSInteger)row
{
    NSInteger time =[self bodyListModelForRow:row].duration;
    return [NSString stringWithFormat:@"%.2ld:%.2ld",time/60,time%60];
}
@end
