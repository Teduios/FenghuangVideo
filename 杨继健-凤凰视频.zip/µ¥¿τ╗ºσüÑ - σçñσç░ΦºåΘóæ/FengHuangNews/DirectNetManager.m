//
//  DirectNetManager.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DirectNetManager.h"

#define kDirectPath @"http://vcsp.ifeng.com/vcsp/appData/liveRecommend.do?useType=iPhone&channelLid=133583-0"
@implementation DirectNetManager
/**
http://vcsp.ifeng.com/vcsp/appData/liveRecommend.do?useType=iPhone&channelLid=133583-0
 */
+(id)getDirectDataCompletionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = kDirectPath;
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([FHDirectModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
