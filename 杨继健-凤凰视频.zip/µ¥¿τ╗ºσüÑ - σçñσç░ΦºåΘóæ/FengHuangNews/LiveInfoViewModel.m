//
//  LiveInfoViewModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LiveInfoViewModel.h"

@implementation LiveInfoViewModel
-(instancetype)initWithType:(PlatType)type
{
    if (self = [super init]) {
        self.infoType = type;
    }
    return self;
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [PlatNetManger getPlatDataWithType:self.infoType completionHandle:^(PlatModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.liveInfo];
        completionHandle(error);
    }];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(NSInteger)rowNumber
{
    return self.dataArr.count;
}
-(PlatLiveinfoModel *)platLiveInfoForRow:(NSInteger)row
{
    return self.dataArr[row];
}
-(NSURL *)bkgIconURLForLiveInfo:(NSInteger)row
{
    return [NSURL URLWithString:[self platLiveInfoForRow:row].bkgURL];
}
-(NSString *)titlwForLiveInfo:(NSInteger)row
{
    return [self platLiveInfoForRow:row].cName;
}
-(NSURL *)playerURLForLiveInfo:(NSInteger)row
{
    return [NSURL URLWithString:[self platLiveInfoForRow:row].shareUrl];
}
@end
