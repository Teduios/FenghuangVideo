//
//  FHGroupViewModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "FengHuangNetManager.h"
@interface FHGroupViewModel : BaseViewModel
-(instancetype)initWithInfoType:(FengHuangType)type;
@property (nonatomic) FengHuangType infoType;
/**
 *  起始页数
 */
@property (nonatomic)NSInteger pageId;
/**
 *  cell个数
 */
@property (nonatomic)NSInteger rowNumber;

-(NSString *)titleInRecomentListFowRow:(NSInteger)row;
-(NSURL *)imageURLInRecomentListFowRow:(NSInteger)row;
-(NSString *)playTimeInRecomentListFowRow:(NSInteger)row;
-(NSString *)durationInRecomentListFowRow:(NSInteger)row;
-(NSInteger)itemIdListInRecomentListFowRow:(NSInteger)row;
-(NSString *)guiIdListInRecomentListFowRow:(NSInteger)row;
/**
 *  头部数组
 */
@property (nonatomic, strong) NSArray *headerArr;
@property (nonatomic) NSInteger headRowNumber;

-(NSString *)titleInHeaderForRow:(NSInteger )row;
-(NSURL *)imageURLInHeaderForRow:(NSInteger )row;
-(NSArray *)imagesURLForHeader;
@end
