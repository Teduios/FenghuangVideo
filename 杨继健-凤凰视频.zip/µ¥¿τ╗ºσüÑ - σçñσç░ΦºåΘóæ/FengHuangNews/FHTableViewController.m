//
//  FHTableViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHTableViewController.h"
#import "FHViewModel.h"
#import "FengHuangModel.h"
#import "FHJinXuanCell.h"
#import "iCarousel.h"
#import "VideoPlayerViewController.h"


@interface FHTableViewController ()<iCarouselDelegate,iCarouselDataSource>
@property (nonatomic, strong) FHViewModel *FHVM;
@property (nonatomic, strong) iCarousel *headerIc;
@property (nonatomic, strong)UILabel *label;
@property (nonatomic, strong)UIPageControl *pageVC;

@end

@implementation FHTableViewController
-(iCarousel *)headerIc
{
    if (!_headerIc) {
        _headerIc = [[iCarousel alloc]init];
        _headerIc.type = 0;
        _headerIc.delegate = self;
        _headerIc.dataSource = self;
        _headerIc.pagingEnabled = YES;
    }
    return _headerIc;
}
-(FHViewModel *)FHVM
{
    if (!_FHVM) {
        _FHVM = [[FHViewModel alloc]init];
    }
    return _FHVM;
}

/**
 *  头部视图
 */
-(UIView *)headerView
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, kWindowW/750 * 500)];
    [view addSubview:self.headerIc];
    [self.headerIc mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    /** 底边框 */
    UIView *bottomView = [UIView new];
    bottomView.backgroundColor = [UIColor blackColor];
    bottomView.alpha = 0.3;
    [view addSubview:bottomView];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.mas_equalTo(0);
        make.height.mas_equalTo(30);
    }];
    /** 标题LB */
    UILabel *label = [UILabel new];
    self.label = label;
    label.text = [self.FHVM titleInHeaderForRow:self.headerIc.currentItemIndex];
    
    label.textColor = [UIColor whiteColor];
    [view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(bottomView.mas_width);
        make.height.mas_equalTo(bottomView.mas_height);
        make.left.bottom.mas_equalTo(0);
    }];
    /** 小点 */
    UIPageControl *pageVC = [[UIPageControl alloc]init];
    self.pageVC = pageVC;
    pageVC.numberOfPages = self.FHVM.headRowNumber;
    [view addSubview:pageVC];
    [pageVC mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(view.mas_centerX);
        make.left.right.mas_equalTo(0);
        make.bottom.mas_equalTo(label.mas_topMargin).mas_equalTo(0);
    }];
    pageVC.pageIndicatorTintColor = [UIColor blueColor];
    pageVC.currentPageIndicatorTintColor = [UIColor whiteColor];
    pageVC.userInteractionEnabled = NO;
    
    
    [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
    
        [_headerIc scrollToItemAtIndex:_headerIc.currentItemIndex+1 animated:YES];
        
    } repeats:YES];
    
    return view;
}
-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    return value;
}
-(void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel
{
    self.label.text = [self.FHVM titleInHeaderForRow:self.headerIc.currentItemIndex];
    self.pageVC.currentPage = _headerIc.currentItemIndex;
}
-(void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index
{
    VideoPlayerViewController *vc = [VideoPlayerViewController new];
    vc.guid = [self.FHVM guidInHeaderForRow:index];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[FHJinXuanCell class] forCellReuseIdentifier:@"Cell"];
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.FHVM refreshDataCompletionHandle:^(NSError *error) {
            self.tableView.tableHeaderView = [self headerView];
            [self.tableView.mj_header endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.toolbarHidden = YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - iCarouselDataSource
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.FHVM.headRowNumber;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(nullable UIView *)view
{
    if (!view) {
//        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH/4)];
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/750 * 500)];;
        UIImageView *iconVC = [UIImageView new];
        iconVC.tag = 100;
        iconVC.contentMode = 2;
        iconVC.clipsToBounds = YES;
        [view addSubview:iconVC];
        [iconVC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *iconVC = (UIImageView *)[view viewWithTag:100];
    [iconVC setImageWithURL:[self.FHVM imageURLInHeaderForRow:index]];
    
    
    return view;
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 13;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.FHVM rowNumberWithSection:section];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FHJinXuanCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    cell.iconView.image = nil;
    [cell.iconView setImageWithURL:[self.FHVM iconURLForIndexInRecommendList:indexPath]placeholderImage:[UIImage imageNamed:@"Default_Logo"]];
   
    
    cell.titleTF.text = [self.FHVM titleForIndexInRecommendList:indexPath];
    
    cell.zhuanTi.hidden = [self.FHVM isHiddenWithRow:indexPath];
    if ([self.FHVM isVideoWithRow:indexPath]) {
        cell.playTime.text = [self.FHVM playTimeForIndexInRecommendList:indexPath];
        cell.videoTime.text = [self.FHVM durationForIndexInRecommendList:indexPath];
    }else{
        cell.playTime.hidden = YES;
        cell.videoTime.hidden = YES;
    }
    
    return cell;
}

kRemoveCellSeparator
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    VideoPlayerViewController *vc = [VideoPlayerViewController new];
    vc.guid = [self.FHVM guidInRecommendForIndexPath:indexPath];
    if (![self.FHVM isVideoWithRow:indexPath]) {
        vc.memberid = [self.FHVM memberidInRecommendForIndexPath:indexPath];
    }
    [self.navigationController pushViewController:vc animated:YES];
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0;
    }
    return [self.FHVM groupTitleForSection:section];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
