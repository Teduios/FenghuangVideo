//
//  FHDirectModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHDirectModel.h"

@implementation FHDirectModel


+ (NSDictionary *)objectClassInArray{
    return @{@"bodyList" : [DirectBodylist class], @"header" : [DirectHeaderModel class]};
}
@end
@implementation DirectBodylist

@end


@implementation DirectHeaderModel

@end


