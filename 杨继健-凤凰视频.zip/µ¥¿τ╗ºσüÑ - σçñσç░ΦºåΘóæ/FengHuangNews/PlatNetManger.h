//
//  PlatNetManger.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "PlatModel.h"
typedef NS_ENUM(NSUInteger, PlatType) {
    PlatTypefenghuang,
    PlatTypecctv,
    PlatTypedifangWS,
    PlatTypedifangGQ,
    PlatTypetese,
    PlatTypegedi,
    PlatTypexiongmao,
    PlatTypewaiwen,
};
@interface PlatNetManger : BaseNetManager
+(id)getPlatDataWithType:(PlatType)type kCompletionHandle;
@end
