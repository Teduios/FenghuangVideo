//
//  HeaderCollectionViewCell.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HeaderCollectionViewCell.h"
@interface HeaderCollectionViewCell()<iCarouselDelegate,iCarouselDataSource>

@property (nonatomic, strong)UIView *bottomView;

@end
@implementation HeaderCollectionViewCell

- (UILabel *)lable {
    if(_lable == nil) {
        _lable = [[UILabel alloc] init];
        _lable.textColor = [UIColor whiteColor];
    }
    return _lable;
}

- (iCarousel *)headerIC {
	if(_headerIC == nil) {
		_headerIC = [[iCarousel alloc] init];
        _headerIC.type = 0;
        _headerIC.delegate = self;
        _headerIC.dataSource = self;
        _headerIC.pagingEnabled = YES;
	}
	return _headerIC;
}

- (UIPageControl *)pageVC {
	if(_pageVC == nil) {
		_pageVC = [[UIPageControl alloc] init];
        _pageVC.pageIndicatorTintColor = [UIColor blueColor];
        _pageVC.currentPageIndicatorTintColor = [UIColor whiteColor];
        _pageVC.userInteractionEnabled = NO;
        
	}
	return _pageVC;
}

- (UIView *)bottomView {
	if(_bottomView == nil) {
		_bottomView = [[UIView alloc] init];
        _bottomView.backgroundColor = [UIColor blackColor];
        _bottomView.alpha = 0.3;
	}
	return _bottomView;
}
- (NSMutableArray *)titles {
    if(_titles == nil) {
        _titles = [[NSMutableArray alloc] init];
    }
    return _titles;
}
- (NSMutableArray *)headerImages {
    if(_headerImages == nil) {
        _headerImages = [[NSMutableArray alloc] init];
    }
    return _headerImages;
}
-(NSInteger)imagesNumber
{
    return self.headerImages.count;
}
-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionWrap) {
        return YES;
    }
    return value;
}
-(void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel
{
    if (_headerIC.currentItemIndex<0) {
        return;
    }
    self.lable.text = self.titles[_headerIC.currentItemIndex];
    self.pageVC.currentPage = _headerIC.currentItemIndex;
}
#pragma mark - iCarouselDataSource
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.imagesNumber;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(nullable UIView *)view
{
    if (!view) {
        //        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH/4)];
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/750 * 500)];;
        UIImageView *iconVC = [UIImageView new];
        iconVC.tag = 100;
        iconVC.contentMode = 2;
        iconVC.clipsToBounds = YES;
        [view addSubview:iconVC];
        [iconVC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *iconVC = (UIImageView *)[view viewWithTag:100];
    [iconVC setImageWithURL:self.headerImages[index]];
    
    
    return view;
    
}

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.headerIC];
        [self addSubview:self.pageVC];
        [self addSubview:self.bottomView];
        [self addSubview:self.lable];
        [self.headerIC mas_makeConstraints:^(MASConstraintMaker *make) {
             make.edges.mas_equalTo(0);
        }];
        [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(0);
            make.height.mas_equalTo(30);
        }];
        [self.lable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(self.bottomView.mas_height);
            make.left.bottom.right.mas_equalTo(0);
        }];
        [self.pageVC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.bottom.mas_equalTo(self.lable.mas_topMargin).mas_equalTo(0);
        }];
        
        [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
            [_headerIC scrollToItemAtIndex:_headerIC.currentItemIndex+1 animated:YES];
            
        } repeats:YES];
    }
    return self;
}

@end
