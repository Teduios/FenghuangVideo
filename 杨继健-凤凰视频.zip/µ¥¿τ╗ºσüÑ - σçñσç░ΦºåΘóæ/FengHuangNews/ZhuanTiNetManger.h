//
//  ZhuanTiNetManger.h
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/25.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface ZhuanTiNetManger : BaseNetManager
+(id)getVideoDataWithMemberID:(NSString *)menberId kCompletionHandle;
@end
