//
//  FHJinXuanCell.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHJinXuanCell.h"

@implementation FHJinXuanCell
- ( UILabel *)titleTF {
    if(_titleTF == nil) {
        _titleTF = [[UILabel alloc] init];
        _titleTF.numberOfLines = 0;
        _titleTF.font = [UIFont systemFontOfSize:18];
    }
    return _titleTF;
}

- ( UILabel *)playTime {
    if(_playTime == nil) {
        _playTime = [[UILabel alloc] init];
        _playTime.textColor = [UIColor grayColor];
        _playTime.font = [UIFont systemFontOfSize:14];
    }
    return _playTime;
}

- ( UILabel *)videoTime {
    if(_videoTime == nil) {
        _videoTime = [[UILabel alloc]init];
        _videoTime.textColor = [UIColor grayColor];
        _videoTime.font = [UIFont systemFontOfSize:14];
    }
    return _videoTime;
}

- (UIImageView *)iconView {
    if(_iconView == nil) {
        _iconView = [[UIImageView alloc] init];
        _iconView.contentMode = 2;
        _iconView.clipsToBounds = YES;
    }
    return _iconView;
}

-(UILabel *)zhuanTi
{
    if (!_zhuanTi) {
        _zhuanTi = [UILabel new];
        _zhuanTi.layer.borderWidth = 1.0;
        _zhuanTi.layer.borderColor = [UIColor redColor].CGColor;
        _zhuanTi.layer.cornerRadius = 3;
        _zhuanTi.font = [UIFont systemFontOfSize:14];
        _zhuanTi.textColor = [UIColor redColor];
        _zhuanTi.text = @"专题";
    }
    return _zhuanTi;
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self addSubview:self.titleTF];
        [self addSubview:self.iconView];
        [self addSubview:self.zhuanTi];
        [self addSubview:self.playTime];
        [self addSubview:self.videoTime];
        
        [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(3);
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(8);
            make.width.mas_equalTo(120);
        }];
        [self.titleTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconView.mas_right).mas_equalTo(8);
            make.right.mas_equalTo(-8);
            make.top.mas_equalTo(3);
            make.height.mas_lessThanOrEqualTo(60);
        }];
        [self.videoTime mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconView.mas_right).mas_equalTo(8);
            make.bottom.mas_equalTo(-3);
        }];
        [self.playTime mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.videoTime.mas_right).mas_equalTo(8);
            make.bottom.mas_equalTo(-3);
        }];
        [self.zhuanTi mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.bottom.mas_equalTo(-3);
        }];
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
