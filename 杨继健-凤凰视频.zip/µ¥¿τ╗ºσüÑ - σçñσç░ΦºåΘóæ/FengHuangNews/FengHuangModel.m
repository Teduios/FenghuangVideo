//
//  FengHuangModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FengHuangModel.h"

@implementation FengHuangModel


+ (NSDictionary *)objectClassInArray{
    return @{@"header" : [FHHeaderModel class]};
}
@end
@implementation FHBodyrecommendModel

+ (NSDictionary *)objectClassInArray{
    return @{@"recommendList" : [FHRecommendlistModel class]};
}

@end


@implementation FHRecommendlistModel

+ (NSDictionary *)objectClassInArray{
    return @{@"groupList" : [FHGrouplistModel class], @"recommend" : [FHRecommendModel class]};
}

@end


@implementation FHGrouplistModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID": @"id"};
}
@end


@implementation FHRecommendModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID": @"id"};
}
@end


@implementation FHHeaderModel

@end


@implementation FHMemberitemModel

@end


