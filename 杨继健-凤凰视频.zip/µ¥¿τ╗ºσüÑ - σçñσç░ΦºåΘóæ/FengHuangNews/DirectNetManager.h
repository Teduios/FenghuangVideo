//
//  DirectNetManager.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "FHDirectModel.h"
@interface DirectNetManager : BaseNetManager
+(id)getDirectDataCompletionHandle:(void(^)(id model, NSError *error))completionHandle;
@end
