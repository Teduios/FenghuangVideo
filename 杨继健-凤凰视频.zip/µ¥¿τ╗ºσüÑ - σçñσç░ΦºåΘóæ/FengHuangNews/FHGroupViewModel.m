//
//  FHGroupViewModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHGroupViewModel.h"
#import "FengHuangGroupModel.h"
@implementation FHGroupViewModel


-(instancetype)initWithInfoType:(FengHuangType)type
{
    if (self = [super init]) {
        self.infoType = type;
    }
    return self;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
     self.dataTask =[FengHuangNetManager getFengHuangWithType:self.infoType positionId:self.pageId completionHandle:^(FengHuangGroupModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.bodyList];
         self.headerArr = model.header;
        completionHandle(error);
    }];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    NSInteger page = self.rowNumber-1;
    self.pageId = [self itemIdListInRecomentListFowRow:page];
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.pageId = 0;
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}

-(FHGroupBodylistModel *)BodylistModelForRow:(NSInteger)row
{
    if (self.dataArr== nil||self.dataArr.count == 0||row>=self.dataArr.count) {
        return nil;
    }
    return self.dataArr[row];
}
-(FHGroupVideolistModel *)videoListModelForRow:(NSInteger)row
{
   return [self BodylistModelForRow:row].videoList.firstObject;
}
-(NSInteger)rowNumber
{
    return self.dataArr.count;
}

-(NSString *)titleInRecomentListFowRow:(NSInteger)row
{
    
    return [self videoListModelForRow:row].title;
}
-(NSURL *)imageURLInRecomentListFowRow:(NSInteger)row
{
    return [NSURL URLWithString:[self videoListModelForRow:row].image];
}
-(NSString *)playTimeInRecomentListFowRow:(NSInteger)row
{
    return [self videoListModelForRow:row].playTime;
}
-(NSString *)durationInRecomentListFowRow:(NSInteger)row
{
    NSInteger time = [self videoListModelForRow:row].memberItem.duration;
    return [NSString stringWithFormat:@"%.2ld:%.2ld",time/60,time%60];
}
-(NSString *)guiIdListInRecomentListFowRow:(NSInteger)row
{
    
    return [self videoListModelForRow:row].memberItem.guid;
}
/**
 *  获得更多的页数
 */
-(NSInteger)itemIdListInRecomentListFowRow:(NSInteger)row
{
    return [self videoListModelForRow:row].ID;
}

-(FHGroupHeaderModel *)GroupHeaderModelForRow:(NSInteger)row
{
    return self.headerArr[row];
}

-(NSInteger)headRowNumber
{
    return self.headerArr.count;
}
-(NSString *)titleInHeaderForRow:(NSInteger)row
{
    return [self GroupHeaderModelForRow:row].title;
}
-(NSURL *)imageURLInHeaderForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self GroupHeaderModelForRow:row].image];
}
-(NSArray *)imagesURLForHeader
{
    NSMutableArray *arr = [NSMutableArray new];
    for (FHGroupHeaderModel *model in self.headerArr) {
        [arr addObject:[NSURL URLWithString:model.image]];
    }
    return [arr copy];
}
@end
