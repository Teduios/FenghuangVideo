//
//  TVViewController.m
//  FengHuangNews
//
//  Created by apple-jd05 on 15/12/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TVViewController.h"
@interface TVViewController()<UIWebViewDelegate>
@property (nonatomic, strong) UIWebView *webVC;
@end
@implementation TVViewController
-(UIWebView *)webVC
{
    if (!_webVC) {
        _webVC = [[UIWebView alloc]init];
    }
    return _webVC;
}
-(void)viewDidLoad
{
    self.webVC.delegate = self;
    [_webVC loadRequest:[NSURLRequest requestWithURL:self.webURL]];
    [self.view addSubview:_webVC];
    [self.webVC mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
}
@end
