//
//  ZhuanTiViewModel.h
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/25.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface ZhuanTiViewModel : BaseViewModel
@property (nonatomic, strong) NSString *memberId;
-(instancetype)initWithMemberId:(NSString *)memberId;
-(NSString *)getGuidForZhuanTi;
@property (nonatomic, strong) NSString *guid;
@end
