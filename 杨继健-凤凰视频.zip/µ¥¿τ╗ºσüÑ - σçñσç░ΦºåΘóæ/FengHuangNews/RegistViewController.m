//
//  RegistViewController.m
//  FengHuangNews
//
//  Created by apple-jd05 on 15/11/24.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "RegistViewController.h"

@interface RegistViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameTF;
@property (weak, nonatomic) IBOutlet UITextField *pwd1;
@property (weak, nonatomic) IBOutlet UITextField *pwd2;

@end

@implementation RegistViewController
- (IBAction)zhuce:(id)sender {
    if (self.userNameTF.text.length == 0||self.pwd1.text.length == 0||self.pwd2.text.length == 0) {
        UIAlertView *waming = [[UIAlertView alloc]initWithTitle:@"警告" message:@"用户名或密码不能为空" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [waming show];
        return;
    }
    if (![_pwd1.text isEqualToString:_pwd2.text]) {
        UIAlertView *waming = [[UIAlertView alloc]initWithTitle:@"警告" message:@"密码不匹配" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [waming show];
        return;
    }
    BmobUser *userLogin = [[BmobUser alloc]init];
    [userLogin setUsername:self.userNameTF.text];
    [userLogin setPassword:self.pwd2.text];
    [userLogin signUpInBackgroundWithBlock:^ (BOOL isSuccessful, NSError *error){
        if (isSuccessful){
            NSLog(@"注册成功");
        } else {
            NSLog(@"%@",error);
        }
    }];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addBackItemToVC:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
