//
//  FHViewModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHViewModel.h"
#import "FengHuangModel.h"
#define kHomeID @"100409-0"
@implementation FHViewModel
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    [FengHuangNetManager getJingXuanWithID:kHomeID completionHandle:^(FengHuangModel *model, NSError *error) {
        
        [self.dataArr addObjectsFromArray:model.bodyRecommend.recommendList];
        _headerArr = model.header;
        completionHandle(error);
    }];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(FHRecommendlistModel *)modelWithSection:(NSInteger)section
{
    if (self.dataArr == nil||self.dataArr.count == 0) {
        return nil;
    }
    return self.dataArr[section];
}
-(BOOL)isHiddenWithRow:(NSIndexPath *)indexPath
{
    BOOL isTag = [[self modelWithSection:indexPath.section].groupList[indexPath.row].tag isEqualToString:@"隐藏"];
    return isTag||[self isVideoWithRow:indexPath];
}
-(BOOL)isVideoWithRow:(NSIndexPath *)indexPath
{
      return  [[self modelWithSection:indexPath.section].groupList[indexPath.row].memberType isEqualToString:@"video"]?YES:NO;
}
-(BOOL)isCmpptopicWithRow:(NSIndexPath *)indexPath
{
    return  [[self modelWithSection:indexPath.section].groupList[indexPath.row].memberType isEqualToString:@"cmpptopic"]?YES:NO;
}
/**
 标题
 */
-(NSString *)titleForIndexInRecommendList:(NSIndexPath *)index
{
    return [self modelWithSection:index.section].groupList[index.row].title;
}
/**
 图片URL
 */
-(NSURL *)iconURLForIndexInRecommendList:(NSIndexPath *)index
{
    return [NSURL URLWithString:[self modelWithSection:index.section].groupList[index.row].image];
}
/**
 播放次数
 */
-(NSString *)playTimeForIndexInRecommendList:(NSIndexPath *)index
{
    return [NSString stringWithFormat:@"播放%@次",[self modelWithSection:index.section].groupList[index.row].playTime];
}
/**
 视频时长
 */
-(NSString *)durationForIndexInRecommendList:(NSIndexPath *)index
{
    NSInteger time = [self modelWithSection:index.section].groupList[index.row].memberItem.duration;
    return [NSString stringWithFormat:@"%.2ld:%.2ld",time/60,time%60];
}
/**
 *  获得分区行数
 */
-(NSInteger)rowNumberWithSection:(NSInteger)section
{
    return [self modelWithSection:section].groupList.count;
}
/**
 *  分区标题
 */
-(NSString *)groupTitleForSection:(NSInteger)section
{
    return [self modelWithSection:section].groupTitle;
}

-(NSString *)guidInRecommendForIndexPath:(NSIndexPath *)index
{
    return [self modelWithSection:index.section].groupList[index.row].memberItem.guid;
}

-(NSString *)memberidInRecommendForIndexPath:(NSIndexPath *)index
{
    return [self modelWithSection:index.section].groupList[index.row].memberId;
}



-(FHHeaderModel *)headerModelWithRow:(NSInteger)row
{
    return self.headerArr[row];
}
/**
 *  头部长度
 */
-(NSInteger)headRowNumber
{
    return self.headerArr.count;
}
/**
 *  获取头部图片
 */
-(NSURL *)imageURLInHeaderForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self headerModelWithRow:row].image];
}
/**
 *  头部标题
 */
-(NSString *)titleInHeaderForRow:(NSInteger)row
{
    return [self headerModelWithRow:row].title;
}

-(NSString *)descInRecommendForIndexPath:(NSIndexPath *)index
{
    return [self modelWithSection:index.section].groupList[index.row].abstractDesc;
}

-(NSString *)guidInHeaderForRow:(NSInteger )row
{
    return [self headerModelWithRow:row].memberItem.guid;
}
@end
