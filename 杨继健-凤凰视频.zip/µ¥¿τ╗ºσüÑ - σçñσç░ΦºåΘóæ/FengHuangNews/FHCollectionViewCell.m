//
//  FHCollectionViewCell.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHCollectionViewCell.h"

@implementation FHCollectionViewCell
- (UIImageView *)iconTV {
    if(_iconTV == nil) {
        _iconTV = [[UIImageView alloc] init];
        _iconTV.contentMode = 2;
        _iconTV.clipsToBounds = YES;
    }
    return _iconTV;
}

- (UILabel *)videoTime {
    if(_videoTime == nil) {
        _videoTime = [[UILabel alloc] init];
        _videoTime.textColor = [UIColor grayColor];
        _videoTime.font = [UIFont systemFontOfSize:14];
    }
    return _videoTime;
}

- (UILabel *)playTIme {
    if(_playTIme == nil) {
        _playTIme = [[UILabel alloc] init];
        _playTIme.textColor = [UIColor grayColor];
        _playTIme.font = [UIFont systemFontOfSize:14];
    }
    return _playTIme;
}

- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] init];
        _titleLB.numberOfLines = 0;
        _titleLB.font = [UIFont systemFontOfSize:16];
    }
    return _titleLB;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.titleLB];
        [self addSubview:self.iconTV];
        [self addSubview:self.playTIme];
        [self addSubview:self.videoTime];
        
        [self.iconTV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.mas_equalTo(0);
            make.height.mas_equalTo(self.mas_height).multipliedBy(0.6);
        }];
        [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.mas_equalTo(self.iconTV.mas_bottom).mas_equalTo(0);
            make.height.mas_equalTo(40);
        }];
        
        [self.videoTime mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(8);
            make.bottom.mas_equalTo(3);
        }];
        [self.playTIme mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.videoTime.mas_rightMargin).mas_equalTo(20);
            make.bottom.mas_equalTo(3);
        }];
    }
    return self;
}
@end
