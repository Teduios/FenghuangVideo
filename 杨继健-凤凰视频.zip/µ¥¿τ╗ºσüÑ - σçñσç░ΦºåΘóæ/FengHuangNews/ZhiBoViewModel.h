//
//  ZhiBoViewModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "DirectNetManager.h"
@interface ZhiBoViewModel : BaseViewModel
@property (nonatomic, assign)NSInteger rowNumber;

-(NSURL *)iconURLForliveRecommend:(NSInteger)row;
-(NSString *)titleForliveRecommend:(NSInteger)row;
-(NSString *)startTimeForliveRecommend:(NSInteger)row;
-(NSURL *)videoForliveRecommend:(NSInteger)row;
@property (nonatomic, strong)NSURL *headerURL;
@end
