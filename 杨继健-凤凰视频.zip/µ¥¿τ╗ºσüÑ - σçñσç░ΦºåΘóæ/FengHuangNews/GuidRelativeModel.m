//
//  GuidRelativeModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "GuidRelativeModel.h"

@implementation GuidRelativeModel


+ (NSDictionary *)objectClassInArray{
    return @{@"guidRelativeVideoInfo" : [FHGuidrelativevideoinfoModel class]};
}
@end
@implementation FHGuidrelativevideoinfoModel

+ (NSDictionary *)objectClassInArray{
    return @{@"files" : [FHFilesModel class]};
}

@end


@implementation FHFilesModel

@end


