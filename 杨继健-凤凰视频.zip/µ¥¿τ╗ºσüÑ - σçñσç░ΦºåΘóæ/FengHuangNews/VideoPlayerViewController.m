//
//  VideoPlayerViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoPlayerViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "VideoTableViewCell.h"
#import "ZhuanTiViewModel.h"

@interface VideoPlayerViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong)videoViewModel *videoVM;
@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) ZhuanTiViewModel *zhuantiVM;

/**
 *  数据持久化
 */
@property (nonatomic, strong) NSUserDefaults *userDefault;
@end

@implementation VideoPlayerViewController
+ (AVPlayerViewController *)sharedInstance{
    static AVPlayerViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [AVPlayerViewController new];
    });
    return vc;
}
-(NSUserDefaults *)userDefault{
    if (!_userDefault) {
        _userDefault=[NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}
-(videoViewModel *)videoVM
{
    if (!_videoVM) {
        _videoVM = [[videoViewModel alloc]initWithGuid:self.guid];
    }
    return _videoVM;
}
-(ZhuanTiViewModel *)zhuantiVM
{
    if (!_zhuantiVM) {
        _zhuantiVM = [[ZhuanTiViewModel alloc]initWithMemberId:self.memberid];
    }
    return _zhuantiVM;
}
-(void)saveData
{
    NSMutableArray *arr = [NSMutableArray new];
    [arr addObjectsFromArray:[self.userDefault arrayForKey:@"info"]];
    [arr addObject:[self.videoVM nameForRow:0]];
    
    NSMutableArray *guidArr = [NSMutableArray new];
    [guidArr addObjectsFromArray:[self.userDefault arrayForKey:@"Guid"]];
    [guidArr addObject:self.videoVM.guid];
    
    [self.userDefault setObject:guidArr forKey:@"Guid"];
    [self.userDefault setObject:arr forKey:@"info"];
    [self.userDefault synchronize];
    NSLog(@"gudi %@ ,icon%@,title%@",self.videoVM.guid,[self.videoVM nameForRow:0],[self.videoVM iconUrlForRow:0]);
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [Factory addBackItemToVC:self];
    UIButton *btn = [[UIButton alloc]init];
    [self.view addSubview:btn];
    [btn setBackgroundImage:[UIImage imageNamed:@"audio-background"] forState:0];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(kWindowW, kWindowH/3));
    }];
    UIImageView *playBtn = [UIImageView new];
    [playBtn setImage:[UIImage imageNamed:@"landscape_video"]];
    
    [btn addSubview:playBtn];
    [playBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(btn);
        make.size.mas_equalTo(CGSizeMake(80, 80));
    }];
    [btn bk_addEventHandler:^(id sender) {
        if (!self.player) {
            self.player = [AVPlayer playerWithURL:[self.videoVM mediaURLForRow:0]];
            [VideoPlayerViewController sharedInstance].player = self.player;
            [btn addSubview:[VideoPlayerViewController sharedInstance].view];
            [[VideoPlayerViewController sharedInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(0);
            }];
            NSLog(@"============%@",[self.videoVM mediaURLForRow:0]);
            [[VideoPlayerViewController sharedInstance].player play];
            
            /** 保存*/
            [self saveData];
        }
        
    } forControlEvents:UIControlEventTouchUpInside];
  
    
    UITableView *videoTable = [[UITableView alloc]init];
    videoTable.delegate = self;
    videoTable.dataSource = self;
    [self.view addSubview:videoTable];
    [videoTable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(0);
        
    }];
    videoTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.zhuantiVM refreshDataCompletionHandle:^(NSError *error) {
            NSLog(@"=======%@",self.zhuantiVM.guid);
            if (_guid ==nil) {
                self.guid = self.zhuantiVM.guid;
                _videoVM = [[videoViewModel alloc]initWithGuid:self.guid];
                [videoTable.mj_header beginRefreshing];
     
            }
        }];
        [self.videoVM refreshDataCompletionHandle:^(NSError *error) {
            [videoTable reloadData];
            [videoTable.mj_header endRefreshing];
        }];
    }];
    dispatch_async(dispatch_get_main_queue(), ^{
        [videoTable.mj_header beginRefreshing];
    });
    
    [videoTable registerClass:[VideoTableViewCell class] forCellReuseIdentifier:@"Cell"];
}

-(void)viewDidDisappear:(BOOL)animated
{
//    [[VideoPlayerViewController sharedInstance].player pause];
    [[VideoPlayerViewController sharedInstance].player replaceCurrentItemWithPlayerItem:nil];
    
}



#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.videoVM.rowNumber;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    VideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    cell.titleLB.textColor = [UIColor blackColor];
    if (indexPath.row==0) {
        cell.titleLB.textColor = [UIColor redColor];
    }
    cell.titleLB.text = [self.videoVM nameForRow:indexPath.row];
    [cell.iconView setImageWithURL:[self.videoVM iconUrlForRow:indexPath.row]placeholderImage:[UIImage imageNamed:@"Default_Logo"]];
    cell.playTime.text = [self.videoVM playTimeFowRow:indexPath.row];
    cell.videoTime.text = [self.videoVM durationFowRow:indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}

kRemoveCellSeparator
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    VideoPlayerViewController *vc = [VideoPlayerViewController new];
    vc.guid = [self.videoVM guidFowRow:indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
