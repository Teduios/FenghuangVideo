//
//  FHDirectModel.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class DirectBodylist,DirectHeaderModel;
@interface FHDirectModel : BaseModel

@property (nonatomic, strong) NSArray<DirectBodylist *> *bodyList;

@property (nonatomic, strong) NSArray<DirectHeaderModel *> *header;

@end
@interface DirectBodylist : NSObject

@property (nonatomic, copy) NSString *channelId;

@property (nonatomic, copy) NSString *programTitle;

@property (nonatomic, copy) NSString *channelName;

@property (nonatomic, copy) NSString *contId;

@property (nonatomic, copy) NSString *day;

@property (nonatomic, copy) NSString *nodeId;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *endTime;

@property (nonatomic, copy) NSString *videoH;

@property (nonatomic, copy) NSString *videoM;

@property (nonatomic, copy) NSString *videoL;

@property (nonatomic, copy) NSString *startTime;

@property (nonatomic, copy) NSString *status;

@property (nonatomic, copy) NSString *video;

@end

@interface DirectHeaderModel : NSObject

@property (nonatomic, copy) NSString *nodeId;

@property (nonatomic, copy) NSString *contId;

@property (nonatomic, copy) NSString *channelId;

@property (nonatomic, copy) NSString *videoH;

@property (nonatomic, copy) NSString *videoM;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *videoL;

@property (nonatomic, copy) NSString *video;

@end

