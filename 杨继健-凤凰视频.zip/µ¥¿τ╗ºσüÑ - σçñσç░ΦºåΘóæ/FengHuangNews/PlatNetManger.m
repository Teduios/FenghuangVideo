//
//  PlatNetManger.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PlatNetManger.h"

#define kPlatPath @"http://vcsp.ifeng.com/vcsp/appData/live.do?platformType=iPhone&channelLid=133583-%d"
@implementation PlatNetManger
+(id)getPlatDataWithType:(PlatType)type completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = nil;
    switch (type) {
        case PlatTypefenghuang: {
            path = [NSString stringWithFormat:kPlatPath,1];
            break;
        }
        case PlatTypecctv: {
            path = [NSString stringWithFormat:kPlatPath,2];
            break;
        }
        case PlatTypedifangWS: {
            path = [NSString stringWithFormat:kPlatPath,3];
            break;
        }
        case PlatTypedifangGQ: {
            path = [NSString stringWithFormat:kPlatPath,4];
            break;
        }
        case PlatTypetese: {
            path = [NSString stringWithFormat:kPlatPath,5];
            break;
        }
        case PlatTypegedi: {
            path = [NSString stringWithFormat:kPlatPath,6];
            break;
        }
        case PlatTypexiongmao: {
            path = [NSString stringWithFormat:kPlatPath,7];
            break;
        }
        case PlatTypewaiwen: {
            path = [NSString stringWithFormat:kPlatPath,8];
            break;
        }
        default: {
            break;
        }
    }
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([PlatModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
