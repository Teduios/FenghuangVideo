//
//  FHTabBarViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FHTabBarViewController.h"
#import "FHTableViewController.h"
#import "FHGroupCollectionViewController.h"
#import "FHDetailCollectionViewController.h"
#import "BaseNavigationController.h"
#import <WMPageController.h>
#import "MyTableViewController.h"
#import "ZBViewController.h"
#import "LiveViewController.h"
@interface FHTabBarViewController ()

@end

@implementation FHTabBarViewController
+(void)initialize
{

}
- (void)viewDidLoad {
    [super viewDidLoad];
    WMPageController *vc1 = [self homePageController];
    UIImage *normolImage = [UIImage imageNamed:@"tabBar_homeBT"];
    UIImage *selectImage = [UIImage imageNamed:@"tabBar_homeBT_Selected"];
    [self setChildVC:vc1 andTitle:nil andNormalImage:normolImage andSelectedImage:selectImage];
    
    WMPageController *vc2 = [self liveController];
    normolImage = [UIImage imageNamed:@"tabBar_liveBT"];
    selectImage = [UIImage imageNamed:@"tabBar_liveBT_Selected"];
    [self setChildVC:vc2 andTitle:nil andNormalImage:normolImage andSelectedImage:selectImage];
    
    WMPageController *vc3 = [self documentaryController];
    
    normolImage = [UIImage imageNamed:@"tabBar_docuBT"];
    selectImage = [UIImage imageNamed:@"tabBar_docuBT_Selected"];
    [self setChildVC:vc3 andTitle:@"" andNormalImage:normolImage andSelectedImage:selectImage];
    
     MyTableViewController *vc4 = [MyTableViewController new];
    normolImage = [UIImage imageNamed:@"tabBar_mineBT"];
    selectImage = [UIImage imageNamed:@"tabBar_mineBT_Selected"];
    [self setChildVC:vc4 andTitle:@"" andNormalImage:normolImage andSelectedImage:selectImage];
    
   
}

/**
 *  用来设置tabbar子控制器的样式
 *
 *  @param vc            传入的控制器
 *  @param title         tabBarItem的title
 *  @param normalImage   tabBarItem的正常图片
 *  @param selectedImage tabBarItem中的被选中时的图片
 */
- (void)setChildVC:(UIViewController *)vc andTitle:(NSString *)title andNormalImage:(UIImage *)normalImage andSelectedImage:(UIImage *)selectedImage {
    [vc.tabBarItem setImage:normalImage];
    vc.tabBarItem.selectedImage = [selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.tabBarItem.imageInsets = UIEdgeInsetsMake(8, 0, -8, 0);
    
 
    BaseNavigationController *nav = [[BaseNavigationController alloc]
                                     initWithRootViewController:vc];

    [self addChildViewController:nav];
    
}

-(WMPageController *)homePageController
{
    NSArray *itemNames = @[@"精选",@"娱乐",@"军事",@"社会",@"搞笑",@"原创",@"历史",@"美女"];
    NSMutableArray *contorllerClass = [[NSMutableArray alloc]init];
    NSMutableArray *pageKeys = [NSMutableArray new];
    NSMutableArray *pageValues = [NSMutableArray new];
    NSInteger count = itemNames.count;
    for (NSInteger i = 0; i < count; i++) {
        if (i==0) {
            [contorllerClass addObject:[FHTableViewController class]];
        }else{
            [contorllerClass addObject:[FHGroupCollectionViewController class]];
        }
        [pageKeys addObject:@"infoType"];
        [pageValues addObject:@(i-1)];
    }
   
    WMPageController *vc = [[WMPageController alloc]initWithViewControllerClasses:contorllerClass andTheirTitles:itemNames];
    vc.keys = pageKeys;
    vc.values = pageValues;
    vc.menuViewStyle = WMMenuViewStyleLine;
    return vc;
}

-(WMPageController *) documentaryController
{
    NSArray *itemNames = @[@"推荐",@"军事",@"历史",@"社会",@"人物",@"探索",@"文化"];
    NSMutableArray *contorllerClass = [[NSMutableArray alloc]init];
    NSMutableArray *pageKeys = [NSMutableArray new];
    NSMutableArray *pageValues = [NSMutableArray new];
    NSInteger count = itemNames.count;
    for (NSInteger i = 0; i < count; i++) {
        if (i==0) {
            [contorllerClass addObject:[FHGroupCollectionViewController class]];
            [pageValues addObject:@(7)];
        }else{
            [contorllerClass addObject:[FHDetailCollectionViewController class]];
            [pageValues addObject:@(i-1)];
        }
        [pageKeys addObject:@"infoType"];
        
    }
    
    WMPageController *vc = [[WMPageController alloc]initWithViewControllerClasses:contorllerClass andTheirTitles:itemNames];
    vc.keys = pageKeys;
    vc.values = pageValues;
    vc.menuViewStyle = WMMenuViewStyleLine;
    return vc;
}

-(WMPageController *)liveController
{
    NSArray *itemNames = @[@"推荐",@"凤凰",@"CCTV",@"地方卫视",@"地方高清",@"特色频道",@"各地频道",@"熊猫频道",@"外文频道"];
    NSMutableArray *contorllerClass = [[NSMutableArray alloc]init];
    NSMutableArray *pageKeys = [NSMutableArray new];
    NSMutableArray *pageValues = [NSMutableArray new];
    NSInteger count = itemNames.count;
    for (NSInteger i = 0; i < count; i++) {
        if (i==0) {
            [contorllerClass addObject:[ZBViewController class]];
        }else{
            [contorllerClass addObject:[LiveViewController class]];
           
        }
        [pageValues addObject:@(i-1)];
        [pageKeys addObject:@"infoType"];
        
    }
    
    WMPageController *vc = [[WMPageController alloc]initWithViewControllerClasses:contorllerClass andTheirTitles:itemNames];
    vc.keys = pageKeys;
    vc.values = pageValues;
    vc.menuViewStyle = WMMenuViewStyleLine;
    vc.itemsWidths = @[@60,@60,@60,@80,@80,@80,@80,@80,@80];
    return vc;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
