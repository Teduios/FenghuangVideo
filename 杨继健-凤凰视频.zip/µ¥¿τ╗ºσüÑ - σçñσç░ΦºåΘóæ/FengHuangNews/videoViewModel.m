//
//  videoViewModel.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "videoViewModel.h"

@implementation videoViewModel
-(instancetype)initWithGuid:(NSString *)guid
{
    if (self = [super init]) {
        self.guid = guid;
    }
    return self;
}
-(NSInteger)rowNumber
{
    return self.dataArr.count;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [VideoNetManager getVideoDataWithGuId:self.guid completionHandle:^(GuidRelativeModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.guidRelativeVideoInfo];
        completionHandle(error);
    }];
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}

-(FHGuidrelativevideoinfoModel *)GuidrelativevideoinfoForRow:(NSInteger )row
{
    if (self.dataArr==nil||self.dataArr.count==0) {
        return nil;
    }
    return  self.dataArr[row];
}
-(FHFilesModel *)FilesForRow:(NSInteger)row Index:(NSInteger)index
{
    return [self GuidrelativevideoinfoForRow:row].files[index];
}



-(NSURL *)mediaURLForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self FilesForRow:row Index:0].mediaUrl];
}
-(NSURL *)iconUrlForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self FilesForRow:row Index:1].mediaUrl];
}
-(NSString *)nameForRow:(NSInteger)row
{
    return [self GuidrelativevideoinfoForRow:row].name;
}
-(NSString *)playTimeFowRow:(NSInteger)row
{
    return  [self GuidrelativevideoinfoForRow:row].playTime;
}
-(NSString *)durationFowRow:(NSInteger)row
{
    NSInteger time = [self GuidrelativevideoinfoForRow:row].duration;
    return [NSString stringWithFormat:@"%.2ld:%.2ld",time/60,time%60];
}
-(NSString *)guidFowRow:(NSInteger)row
{
    return [self GuidrelativevideoinfoForRow:row].guid;
}
@end
