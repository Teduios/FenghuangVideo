//
//  LoginViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LoginViewController.h"
#import "MyTableViewController.h"
@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;

@end

@implementation LoginViewController
- (IBAction)loginFH:(id)sender {
   
    if (self.userTF.text.length == 0) {
        UIAlertView *woring = [[UIAlertView alloc]initWithTitle:@"错误" message:@"请输入账号" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        //设置警告框的样式
        woring.alertViewStyle = 0;
        [woring show];
    }else if (self.passwordTF.text.length == 0) {
        UIAlertView *woring = [[UIAlertView alloc]initWithTitle:@"错误" message:@"请输入密码" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [woring show];
    }else{
        NSString *name = self.userTF.text;
        NSString *pwd = self.passwordTF.text;
        NSLog(@"%@",name);
        NSLog(@"%@",pwd);
        
        [BmobUser loginWithUsernameInBackground:name password:pwd block:^(BmobUser *user, NSError *error) {
            if (user) {
                [self.delegate getUserInfoWithDic:name];
                [self.navigationController popViewControllerAnimated:YES];
            }else{
                UIAlertView *woring = [[UIAlertView alloc]initWithTitle:@"错误" message:@"账号或密码错误" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [woring show];
            }
        }];
//        BmobQuery *bquery = [BmobQuery queryWithClassName:@"userLoginInfo"];
//        [bquery whereKey:@"Name" equalTo:name];
//        [bquery whereKey:@"password" equalTo:pwd];
//        [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
//            if (array.count == 0) {
//                 UIAlertView *woring = [[UIAlertView alloc]initWithTitle:@"错误" message:@"账号或密码错误" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//                [woring show];
//            }else{
//                [self.delegate getUserInfoWithDic:name];
//                [self.navigationController popViewControllerAnimated:YES];
//            }
//        }];
        
    }
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addBackItemToVC:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
