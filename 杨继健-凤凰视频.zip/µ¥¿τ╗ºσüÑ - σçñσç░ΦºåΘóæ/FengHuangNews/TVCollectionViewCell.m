//
//  TVCollectionViewCell.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TVCollectionViewCell.h"

@implementation TVCollectionViewCell
- (UIImageView *)iconTV {
    if(_iconTV == nil) {
        _iconTV = [[UIImageView alloc] init];
        _iconTV.contentMode = 1;
    }
    return _iconTV;
}

- (UILabel *)lable {
    if(_lable == nil) {
        _lable = [[UILabel alloc] init];
        _lable.textAlignment = NSTextAlignmentCenter;
    }
    return _lable;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.iconTV];
        [self addSubview:self.lable];
        [self.iconTV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            make.bottom.mas_equalTo(self.lable.mas_top).mas_equalTo(8);
            
        }];
        [self.lable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.bottom.mas_equalTo(-10);
            
        }];
    }
    return self;
}
@end
