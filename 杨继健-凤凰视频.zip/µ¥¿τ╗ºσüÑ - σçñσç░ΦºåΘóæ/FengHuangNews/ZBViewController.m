//
//  ZBViewController.m
//  BaseProject
//
//  Created by apple-jd05 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZBViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "ZhiBoViewModel.h"
#import "LiveCollectionViewCell.h"
@interface ZBViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic, strong)ZhiBoViewModel *zbVM;
@property (nonatomic, strong) AVPlayerViewController *playerVC;
@property (nonatomic, strong) AVPlayer *player;

/** 记录预约*/
@property (nonatomic, strong)NSMutableArray *yuyeArr;
@end

@implementation ZBViewController
+ (AVPlayerViewController *)sharedInstance{
    static AVPlayerViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [AVPlayerViewController new];
    });
    return vc;
}
-(ZhiBoViewModel *)zbVM
{
    if (!_zbVM) {
        _zbVM = [ZhiBoViewModel new];
    }
    return _zbVM;
}
-(NSMutableArray *)yuyeArr
{
    if (!_yuyeArr) {
        _yuyeArr = [[NSMutableArray alloc]init];
    }
    for (NSInteger i = 0; i < self.zbVM.rowNumber; i++) {
        [_yuyeArr addObject:@1];
    }
    return _yuyeArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addBackItemToVC:self];
    UIButton *btn = [[UIButton alloc]init];
    [self.view addSubview:btn];
    [btn setBackgroundImage:[UIImage imageNamed:@"audio-background"] forState:0];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(kWindowW, kWindowH/3));
    }];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake((kWindowW-30)/2, 180);
    layout.minimumInteritemSpacing = 5;
    layout.minimumLineSpacing = 5; //上下的间距 可以设置0看下效果
    layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    
    UICollectionView *infoView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH) collectionViewLayout:layout];
    infoView.delegate =self;
    infoView.dataSource = self;
    infoView.backgroundColor = [UIColor whiteColor];
    
    [infoView registerClass:[LiveCollectionViewCell class] forCellWithReuseIdentifier:@"Cell"];
    
    [self.view addSubview:infoView];
    [infoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.left.bottom.mas_equalTo(0);
        make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(0);
    }];
    
    infoView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.zbVM refreshDataCompletionHandle:^(NSError *error) {
            [infoView reloadData];
            [infoView.mj_header endRefreshing];
            NSLog(@"===========%@",[self.zbVM videoForliveRecommend:0]);
            
            /** 获取链接播放视屏 */
            self.player = [AVPlayer playerWithURL:self.zbVM.headerURL];
            if (!self.playerVC) {
//                self.player = [AVPlayer playerWithURL:[NSURL URLWithString:@"http://zv.3gv.ifeng.com/zixun.m3u8"]];
                self.playerVC = [ZBViewController sharedInstance];
                self.playerVC.player = self.player;
                [self.playerVC.player play];
                [btn addSubview:self.playerVC.view];
                [self.playerVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.left.mas_equalTo(0);
                    make.size.mas_equalTo(CGSizeMake(kWindowW, kWindowH/3));
                }];
            }
        }];
    }];
    dispatch_async(dispatch_get_main_queue(), ^{
        [infoView.mj_header beginRefreshing];
    });

    
}

-(void)viewDidDisappear:(BOOL)animated
{
    [self.playerVC.player pause];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.zbVM.rowNumber;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    LiveCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    if (self.yuyeArr[indexPath.row] == @0) {
         [cell.yuyueVC setTitle:@"已预约" forState:0];
    }else{
        [cell.yuyueVC setTitle:@"预约" forState:0];
    }
    [cell.yuyueVC setBackgroundImage:[UIImage imageNamed:@"LDCell_YuYue_NormalBtn"] forState:0];
    if (indexPath.row==0) {
        [cell.yuyueVC setTitle:@"直播中" forState:0];
        [cell.yuyueVC setBackgroundImage:[UIImage imageNamed:@"LDCell_Living_NormalBtn"] forState:0];
    }
    [cell.iconVC setImageWithURL:[self.zbVM iconURLForliveRecommend:indexPath.row]];
    cell.layer.borderWidth = 1;
    cell.titleLB.text = [self.zbVM titleForliveRecommend:indexPath.row];
    cell.timeLB.text = [self.zbVM startTimeForliveRecommend:indexPath.row];
    return cell;                                                                                     
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row != 0) {
        LiveCollectionViewCell *cell = (LiveCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
        if (self.yuyeArr[indexPath.row] == @0) {
            [cell.yuyueVC setTitle:@"预约" forState:0];
            self.yuyeArr[indexPath.row] = @1;
        }else{
            [cell.yuyueVC setTitle:@"已预约" forState:0];
            self.yuyeArr[indexPath.row] = @0;
        }
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
