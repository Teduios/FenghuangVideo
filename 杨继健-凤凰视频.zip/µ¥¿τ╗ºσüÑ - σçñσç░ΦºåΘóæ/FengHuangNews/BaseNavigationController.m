//
//  BaseNavigationController.m
//  糗事百科
//
//  Created by Hanten on 15/11/6.
//  Copyright © 2015年 hzq. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()

@end

@implementation BaseNavigationController

+ (void)initialize
{
    if(self == [BaseNavigationController class])
    {
        
        UINavigationBar *bar = [UINavigationBar appearance];
        [bar setBackgroundImage:[UIImage imageNamed:@"cache_all"] forBarMetrics:UIBarMetricsDefault];
        [bar setBarStyle:UIBarStyleBlack];
        
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *FHlogo = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bar_logo"]];
    FHlogo.frame = CGRectMake(kWindowW/2-60, 5, 120, 25);
    [self.navigationBar addSubview:FHlogo];
    
    UIButton *btn1 = [UIButton new];
    [btn1 setImage:[UIImage imageNamed:@"bar_search"] forState:0];
    btn1.frame = CGRectMake(kWindowW-60, 10, 20, 20);
    [self.navigationBar addSubview:btn1];
    [btn1 bk_addEventHandler:^(id sender) {
        UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"Search"];
        [self presentViewController:vc animated:YES completion:nil];
    } forControlEvents:5];
    
    UIButton *btn2 = [UIButton new];
    [btn2 setImage:[UIImage imageNamed:@"bar_showHistory"] forState:0];
    btn2.frame = CGRectMake(kWindowW-30, 10, 20, 20);
    [self.navigationBar addSubview:btn2];
    /** 添加两个按钮
     */
    
   
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)mySearchbar:(UINavigationController *)nav
{
    UIViewController *vc = [UIViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)myHistory:(UINavigationController *)nav
{
    
}

@end
