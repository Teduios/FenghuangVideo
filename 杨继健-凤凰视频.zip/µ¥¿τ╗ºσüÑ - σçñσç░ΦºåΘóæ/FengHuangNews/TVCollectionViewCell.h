//
//  TVCollectionViewCell.h
//  BaseProject
//
//  Created by apple-jd05 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong)UIImageView *iconTV;
@property (nonatomic, strong)UILabel *lable;


@end
